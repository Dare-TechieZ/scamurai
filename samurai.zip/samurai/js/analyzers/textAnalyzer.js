function isProtectiveContext(text, rule) {
    const protectivePatterns = [
        /\bnever\s+(share|send|provide|reveal|tell)\b/i,
        /\bdo\s+not\s+(share|send|provide|reveal|tell)\b/i,
        /\bdon't\s+(share|send|provide|reveal|tell)\b/i,
        /\bdont\s+(share|send|provide|reveal|tell)\b/i,
        /\bavoid\s+(sharing|sending|providing)\b/i
    ];

    const sensitiveWords = {
        otp: /\botp\b/i,
        password: /\b(password|passcode|pin)\b/i,
        payment: /\b(payment|money|transfer)\b/i,
        credentials: /\b(otp|password|passcode|pin)\b/i
    };

    if (!sensitiveWords[rule.category]) {
        return false;
    }

    const paragraphs = text.split(/[.!?\n]/);

    return paragraphs.some(function (paragraph) {
        return protectivePatterns.some(function (pattern) {
            return pattern.test(paragraph);
        }) && sensitiveWords[rule.category].test(paragraph);
    });
}

function analyzeText(message) {
    const findings = [];
    const normalizedMessage = message.toLowerCase();

    detectionRules.forEach(function (rule) {
        const matched = rule.patterns.some(function (pattern) {
            return pattern.test(normalizedMessage);
        });

        if (matched && !isProtectiveContext(normalizedMessage, rule)) {
            findings.push({
                id: rule.id,
                title: rule.title,
                description: rule.description,
                category: rule.category,
                weight: rule.weight,
                evidence: rule.patterns
                    .filter(function (pattern) {
                        return pattern.test(normalizedMessage);
                    })
                    .map(function (pattern) {
                        return normalizedMessage.match(pattern)?.[0];
                    })
                    .filter(Boolean)
            });
        }
    });

    return findings;
}