function analyzePatterns(findings) {
    const categories = new Set(
        findings.map(function (finding) {
            return finding.category;
        })
    );

    const ids = new Set(
        findings.map(function (finding) {
            return finding.id;
        })
    );

    const detectedPatterns = [];

    scamPatterns.forEach(function (pattern) {
        const matched = pattern.required.every(function (required) {
            return categories.has(required) || ids.has(required);
        });

        if (matched) {
            detectedPatterns.push({
                id: pattern.id,
                title: pattern.title,
                description: pattern.description,
                bonus: pattern.bonus
            });
        }
    });

    return detectedPatterns;
}