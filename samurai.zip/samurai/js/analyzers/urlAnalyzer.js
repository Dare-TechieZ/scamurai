const shortenerDomains = [
    "bit.ly",
    "tinyurl.com",
    "t.co",
    "is.gd",
    "cutt.ly",
    "shorturl.at",
    "rb.gy",
    "rebrand.ly"
];

const suspiciousTlds = [
    ".xyz",
    ".top",
    ".click",
    ".work",
    ".loan",
    ".gq",
    ".tk",
    ".ml",
    ".cf"
];

const knownBrands = [
    "google",
    "amazon",
    "microsoft",
    "apple",
    "paypal",
    "netflix",
    "instagram",
    "facebook",
    "whatsapp",
    "sbi",
    "hdfc",
    "icici",
    "axisbank"
];

function extractUrls(message) {
    const regex = /\b(?:https?:\/\/|www\.)[^\s<>"']+/gi;

    return message.match(regex) || [];
}

function analyzeUrl(rawUrl) {
    const findings = [];

    let cleanedUrl = rawUrl.replace(/[),.!?;]+$/, "");

    if (cleanedUrl.startsWith("www.")) {
        cleanedUrl = "https://" + cleanedUrl;
    }

    let url;

    try {
        url = new URL(cleanedUrl);
    } catch (error) {
        return [{
            id: "invalid_url",
            title: "Unusual link format",
            description: "The URL could not be parsed normally.",
            category: "url",
            weight: 12,
            evidence: [rawUrl]
        }];
    }

    const hostname = url.hostname.toLowerCase();
    const domainParts = hostname.split(".");

    if (url.protocol === "http:") {
        findings.push({
            id: "http_url",
            title: "Unencrypted HTTP link",
            description: "This link uses HTTP rather than HTTPS.",
            category: "url",
            weight: 8,
            evidence: [rawUrl]
        });
    }

    if (url.username || url.password) {
        findings.push({
            id: "url_credentials",
            title: "Credentials inside URL",
            description: "The URL contains a username or password section.",
            category: "url",
            weight: 20,
            evidence: [rawUrl]
        });
    }

    if (shortenerDomains.includes(hostname)) {
        findings.push({
            id: "url_shortener",
            title: "Shortened URL",
            description: "The link uses a URL shortener, hiding its final destination.",
            category: "url",
            weight: 14,
            evidence: [rawUrl]
        });
    }

    const isIPv4 = /^\d{1,3}(?:\.\d{1,3}){3}$/.test(hostname);

    if (isIPv4) {
        findings.push({
            id: "ip_url",
            title: "IP address used as domain",
            description: "The link points directly to an IP address instead of a normal domain.",
            category: "url",
            weight: 18,
            evidence: [rawUrl]
        });
    }

    if (suspiciousTlds.some(function (tld) {
        return hostname.endsWith(tld);
    })) {
        findings.push({
            id: "unusual_tld",
            title: "Unusual domain extension",
            description: "The domain uses an extension commonly worth inspecting carefully.",
            category: "url",
            weight: 10,
            evidence: [rawUrl]
        });
    }

    if (cleanedUrl.length > 100) {
        findings.push({
            id: "long_url",
            title: "Unusually long URL",
            description: "The URL is unusually long and may contain misleading or encoded information.",
            category: "url",
            weight: 7,
            evidence: [rawUrl]
        });
    }

    const hostnameLabels = domainParts.slice(0, -1);

    const suspiciousBrand = knownBrands.find(function (brand) {
        return hostnameLabels.some(function (label) {
            return label.includes(brand) && label !== brand;
        });
    });

    if (suspiciousBrand) {
        findings.push({
            id: "brand_lookalike",
            title: "Possible brand impersonation",
            description: "A brand name appears embedded in a larger domain label. This is not proof of impersonation.",
            category: "url",
            weight: 18,
            evidence: [rawUrl]
        });
    }

    return findings;
}

function analyzeUrls(message) {
    const urls = extractUrls(message);
    let findings = [];

    urls.forEach(function (url) {
        findings = findings.concat(analyzeUrl(url));
    });

    if (urls.length > 0) {
        findings.push({
            id: "url_present",
            title: "External link detected",
            description: "The message contains a link. Verify its destination independently before opening it.",
            category: "url",
            weight: 0,
            evidence: urls
        });
    }

    return {
        urls: urls,
        findings: findings
    };
}