const detectionRules = [
    {
        id: "urgency",
        title: "Urgent language",
        description: "The message pressures the recipient to act immediately.",
        category: "urgency",
        weight: 12,
        patterns: [
            /\b(immediately|urgent|right now|within \d+ hours?|act fast|last chance)\b/i,
            /\b(today only|expires today|limited time|final warning)\b/i
        ]
    },

    {
        id: "threat",
        title: "Threatening language",
        description: "The message threatens account suspension, blocking or legal action.",
        category: "threat",
        weight: 18,
        patterns: [
            /\b(account|card|bank account|sim|service)\b.{0,35}\b(blocked|suspended|closed|deactivated|terminated)\b/i,
            /\b(legal action|arrest warrant|police case|penalty)\b/i
        ]
    },

    {
        id: "otp",
        title: "OTP request",
        description: "The message appears to request or discuss sharing an OTP.",
        category: "credentials",
        weight: 20,
        patterns: [
            /\b(share|send|provide|enter|verify|tell)\b.{0,30}\botp\b/i,
            /\botp\b.{0,30}\b(share|send|provide|enter|reply)\b/i
        ]
    },

    {
        id: "password",
        title: "Password or PIN request",
        description: "The message appears to request sensitive login information.",
        category: "credentials",
        weight: 22,
        patterns: [
            /\b(share|send|provide|enter|confirm)\b.{0,30}\b(password|passcode|pin)\b/i,
            /\b(password|passcode|pin)\b.{0,30}\b(share|send|provide|enter)\b/i
        ]
    },

    {
        id: "payment",
        title: "Payment request",
        description: "The message asks for money, a transfer or an advance payment.",
        category: "payment",
        weight: 15,
        patterns: [
            /\b(pay|payment|transfer|deposit|send money|processing fee|registration fee)\b/i,
            /\b(upi id|bank transfer|account number)\b/i
        ]
    },

    {
        id: "prize",
        title: "Unexpected reward or prize",
        description: "The message claims you have won an unexpected prize or reward.",
        category: "prize",
        weight: 14,
        patterns: [
            /\b(you have won|congratulations.*won|lucky winner|claim your prize)\b/i,
            /\b(free gift|cash reward|lottery winner|selected winner)\b/i
        ]
    },

    {
        id: "kyc",
        title: "KYC or account verification",
        description: "The message uses KYC or verification language.",
        category: "verification",
        weight: 12,
        patterns: [
            /\b(kyc|re-?verify|verify your account|update your details|account verification)\b/i,
            /\b(aadhaar|pan card)\b.{0,35}\b(update|verify|submit)\b/i
        ]
    },

    {
        id: "remote_access",
        title: "Remote access request",
        description: "The message may be asking you to install remote access software.",
        category: "remote_access",
        weight: 25,
        patterns: [
            /\b(anydesk|teamviewer|remote access|screen sharing app)\b/i,
            /\b(install.*app|download.*application)\b.{0,50}\b(support|verification|refund)\b/i
        ]
    }
];