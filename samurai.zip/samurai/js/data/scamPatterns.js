const scamPatterns = [
    {
        id: "banking_phishing",
        title: "Possible banking phishing",
        description: "Threatening account language combined with KYC or verification requests.",
        required: ["threat", "kyc"],
        bonus: 15
    },

    {
        id: "otp_pressure",
        title: "OTP pressure tactic",
        description: "An OTP-related request is combined with urgency.",
        required: ["otp", "urgency"],
        bonus: 15
    },

    {
        id: "advance_fee",
        title: "Possible advance-fee scam",
        description: "An unexpected prize is combined with a payment request.",
        required: ["prize", "payment"],
        bonus: 18
    },

    {
        id: "credential_phishing",
        title: "Possible credential phishing",
        description: "A suspicious link appears alongside a password or OTP request.",
        required: ["credentials", "url"],
        bonus: 20
    },

    {
        id: "urgent_link",
        title: "Urgent link combination",
        description: "The message combines urgency with an external link.",
        required: ["urgency", "url"],
        bonus: 12
    },

    {
        id: "remote_support",
        title: "Possible remote access scam",
        description: "Remote access software is mentioned alongside a payment or verification request.",
        required: ["remote_access", "verification"],
        bonus: 15
    }
];