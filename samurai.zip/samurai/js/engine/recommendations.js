function generateRecommendations(findings) {
    const recommendations = [];

    const categories = new Set(
        findings.map(function (finding) {
            return finding.category;
        })
    );

    if (categories.has("credentials")) {
        recommendations.push({
            title: "Never share OTPs or passwords",
            description: "Banks and legitimate services should not ask you to disclose your OTP, password or PIN through messages."
        });
    }

    if (categories.has("url")) {
        recommendations.push({
            title: "Do not open suspicious links",
            description: "Navigate to the official website manually instead of clicking a link in the message."
        });
    }

    if (categories.has("payment")) {
        recommendations.push({
            title: "Verify payment requests",
            description: "Confirm the request with the organization using an independently verified phone number or official app."
        });
    }

    if (categories.has("threat")) {
        recommendations.push({
            title: "Do not panic",
            description: "Threats about immediate account closure or legal action can be used to pressure victims into making mistakes."
        });
    }

    if (categories.has("prize")) {
        recommendations.push({
            title: "Be careful with unexpected prizes",
            description: "Verify prize claims independently. Be suspicious of requests for advance fees to release a reward."
        });
    }

    if (categories.has("verification")) {
        recommendations.push({
            title: "Verify KYC requests independently",
            description: "Use your bank's official app or website. Never submit identity documents through an unverified link."
        });
    }

    if (categories.has("remote_access")) {
        recommendations.push({
            title: "Avoid unknown remote access apps",
            description: "Do not install remote access software or share your screen at the request of an unverified caller."
        });
    }

    if (recommendations.length === 0) {
        recommendations.push({
            title: "Stay cautious",
            description: "No major warning signs were detected. Still verify unexpected requests and avoid sharing sensitive information."
        });
    }

    return recommendations;
}