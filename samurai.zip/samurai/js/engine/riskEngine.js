function calculateRisk(findings, patterns) {
    let score = 0;

    const uniqueFindings = new Set();

    findings.forEach(function (finding) {
        if (!uniqueFindings.has(finding.id)) {
            score += finding.weight;
            uniqueFindings.add(finding.id);
        }
    });

    patterns.forEach(function (pattern) {
        score += pattern.bonus;
    });

    score = Math.min(score, 100);

    let level;
    let summary;

    if (score >= 60) {
        level = "High Risk";
        summary = "Multiple warning signs were detected. Do not click links or share sensitive information until you independently verify the message.";
    } else if (score >= 30) {
        level = "Medium Risk";
        summary = "Some suspicious characteristics were found. Verify the sender and any requests through official channels.";
    } else {
        level = "Low Risk";
        summary = "Few warning signs were detected by these checks. This does not guarantee that the message is safe.";
    }

    return {
        score: score,
        level: level,
        summary: summary
    };
}