const messageInput = document.getElementById("messageInput");
const analyzeBtn = document.getElementById("analyzeBtn");
const clearBtn = document.getElementById("clearBtn");
const copyBtn = document.getElementById("copyBtn");

const results = document.getElementById("results");
const charCount = document.getElementById("charCount");

let latestReport = "";

messageInput.addEventListener("input", function () {
    charCount.textContent = messageInput.value.length + " / 10000";
});

clearBtn.addEventListener("click", function () {
    messageInput.value = "";
    charCount.textContent = "0 / 10000";
    results.classList.add("hidden");
    latestReport = "";
});

analyzeBtn.addEventListener("click", function () {
    const message = messageInput.value.trim();

    if (!message) {
        alert("Please paste a message before analyzing.");
        return;
    }

    runAnalysis(message);
});


function runAnalysis(message) {

    // 1. Analyze message text
    const textFindings = analyzeText(message);

    // 2. Analyze URLs separately
    const urlResult = analyzeUrls(message);

    // 3. Combine findings for risk calculation
    const allFindings = textFindings.concat(urlResult.findings);

    // 4. Detect suspicious combinations
    const patterns = analyzePatterns(allFindings);

    // 5. Calculate risk score
    const risk = calculateRisk(allFindings, patterns);

    // 6. Generate recommendations
    const recommendations = generateRecommendations(allFindings);

    // 7. Display results in separate sections
    renderResults(
        risk,
        textFindings,
        urlResult.findings,
        patterns,
        recommendations
    );

    latestReport = createReport(
        risk,
        allFindings,
        patterns,
        recommendations
    );

    results.classList.remove("hidden");

    results.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
}

function renderResults(
    risk,
    textFindings,
    urlFindings,
    patterns,
    recommendations
) {
    document.getElementById("riskScore").textContent = risk.score;
    document.getElementById("riskLevel").textContent = risk.level;
    document.getElementById("riskSummary").textContent = risk.summary;

    const scoreCircle = document.getElementById("scoreCircle");

    if (risk.score >= 60) {
        scoreCircle.style.borderColor = "var(--red)";
    } else if (risk.score >= 30) {
        scoreCircle.style.borderColor = "var(--yellow)";
    } else {
        scoreCircle.style.borderColor = "var(--green)";
    }

    renderFindings(textFindings);

    renderUrlFindings(urlFindings);

    renderPatterns(patterns);

    renderRecommendations(recommendations);
}

function createItem(title, description, className) {
    const item = document.createElement("div");
    item.className = className;

    const heading = document.createElement("strong");
    heading.textContent = title;

    const paragraph = document.createElement("p");
    paragraph.textContent = description;

    item.appendChild(heading);
    item.appendChild(paragraph);

    return item;
}

function renderFindings(findings) {
    const container = document.getElementById("findingsList");
    container.replaceChildren();

    if (findings.length === 0) {
        const message = document.createElement("p");
        message.className = "no-findings";
        message.textContent = "No major warning signs detected by the current rules.";
        container.appendChild(message);
        return;
    }

    findings.forEach(function (finding) {
        const evidence = finding.evidence && finding.evidence.length
            ? "Evidence: " + finding.evidence.join(", ")
            : "";

        const description = evidence
            ? finding.description + " " + evidence
            : finding.description;

        container.appendChild(
            createItem(finding.title, description, "finding")
        );
    });
}

function renderUrlFindings(findings) {

    const container = document.getElementById("urlFindingsList");

    container.replaceChildren();

    if (findings.length === 0) {
        const message = document.createElement("p");

        message.className = "no-findings";
        message.textContent = "No URLs or suspicious link characteristics detected.";

        container.appendChild(message);
        return;
    }

    findings.forEach(function (finding) {

        const evidence = finding.evidence && finding.evidence.length
            ? "Evidence: " + finding.evidence.join(", ")
            : "";

        const description = evidence
            ? finding.description + " " + evidence
            : finding.description;

        container.appendChild(
            createItem(finding.title, description, "finding")
        );

    });
}

function renderPatterns(patterns) {
    const container = document.getElementById("patternsList");
    container.replaceChildren();

    if (patterns.length === 0) {
        const message = document.createElement("p");
        message.className = "no-findings";
        message.textContent = "No predefined suspicious combinations detected.";
        container.appendChild(message);
        return;
    }

    patterns.forEach(function (pattern) {
        container.appendChild(
            createItem(pattern.title, pattern.description, "finding")
        );
    });
}

function renderRecommendations(recommendations) {
    const container = document.getElementById("recommendationsList");
    container.replaceChildren();

    recommendations.forEach(function (recommendation) {
        container.appendChild(
            createItem(
                recommendation.title,
                recommendation.description,
                "recommendation"
            )
        );
    });
}

function createReport(risk, findings, patterns, recommendations) {
    let report = "SCAMURAI ANALYSIS REPORT\n";
    report += "========================\n\n";

    report += "Risk score: " + risk.score + "/100\n";
    report += "Risk level: " + risk.level + "\n";
    report += "Summary: " + risk.summary + "\n\n";

    report += "WARNING SIGNS\n";

    findings.forEach(function (finding) {
        report += "- " + finding.title + ": " + finding.description + "\n";
    });

    if (findings.length === 0) {
        report += "- No major warning signs detected.\n";
    }

    report += "\nDETECTED PATTERNS\n";

    patterns.forEach(function (pattern) {
        report += "- " + pattern.title + "\n";
    });

    if (patterns.length === 0) {
        report += "- No predefined combinations detected.\n";
    }

    report += "\nRECOMMENDATIONS\n";

    recommendations.forEach(function (recommendation) {
        report += "- " + recommendation.title + ": " +
            recommendation.description + "\n";
    });

    report += "\nNote: This is a rule-based heuristic assessment, not proof of fraud.";

    return report;
}

copyBtn.addEventListener("click", async function () {
    if (!latestReport) {
        return;
    }

    try {
        await navigator.clipboard.writeText(latestReport);
        copyBtn.textContent = "Copied!";

        setTimeout(function () {
            copyBtn.textContent = "Copy report";
        }, 1500);
    } catch (error) {
        alert("Clipboard access is unavailable. You can select and copy the report manually.");
    }
});