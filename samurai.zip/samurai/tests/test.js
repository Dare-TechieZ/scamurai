const testResults = document.getElementById("testResults");

let passed = 0;
let failed = 0;

function test(name, callback) {
    const result = document.createElement("p");

    try {
        const success = callback();

        if (success) {
            result.textContent = "PASS: " + name;
            result.className = "pass";
            passed++;
        } else {
            result.textContent = "FAIL: " + name;
            result.className = "fail";
            failed++;
        }
    } catch (error) {
        result.textContent = "ERROR: " + name + " — " + error.message;
        result.className = "fail";
        failed++;
    }

    testResults.appendChild(result);
}

test("Detects OTP request", function () {
    return analyzeText("Please share your OTP immediately").some(
        finding => finding.id === "otp"
    );
});

test("Detects account suspension threat", function () {
    return analyzeText("Your bank account will be blocked today").some(
        finding => finding.id === "threat"
    );
});

test("Does not flag protective OTP warning", function () {
    return !analyzeText("Never share your OTP with anyone").some(
        finding => finding.id === "otp"
    );
});

test("Extracts HTTP URL", function () {
    return extractUrls("Visit http://example.com").length === 1;
});

test("Detects shortened URL", function () {
    return analyzeUrl("https://bit.ly/example").some(
        finding => finding.id === "url_shortener"
    );
});

test("Detects OTP pressure pattern", function () {
    const findings = [
        { id: "otp", category: "credentials" },
        { id: "urgency", category: "urgency" }
    ];

    return analyzePatterns(findings).some(
        pattern => pattern.id === "otp_pressure"
    );
});

test("Risk score never exceeds 100", function () {
    const findings = Array.from({ length: 20 }, function (_, index) {
        return {
            id: "test-" + index,
            weight: 25
        };
    });

    return calculateRisk(findings, []).score === 100;
});

test("Does not flag protective password warning", function () {
    return !analyzeText("Never share your password with anyone").some(
        finding => finding.id === "password"
    );
});

const summary = document.createElement("h2");
summary.textContent = "Passed: " + passed + " | Failed: " + failed;

testResults.appendChild(summary);